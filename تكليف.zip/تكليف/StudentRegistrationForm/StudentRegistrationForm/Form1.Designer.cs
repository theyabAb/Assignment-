﻿namespace StudentRegistrationForm
{
    partial class frmRegistration
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblEmail = new Label();
            lblPassword = new Label();
            lblName = new Label();
            lblColor = new Label();
            lblBithdate = new Label();
            lblGender = new Label();
            lblResult = new Label();
            lblCountry = new Label();
            txtName = new TextBox();
            txtEmail = new TextBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            txtPassword = new TextBox();
            grpGender = new GroupBox();
            rdoOther = new RadioButton();
            rdoFemale = new RadioButton();
            rdoMale = new RadioButton();
            btnPickColor = new Button();
            lblSelectedColor = new Label();
            dtpBirthdate = new DateTimePicker();
            cmbCountry = new ComboBox();
            btnSubmit = new Button();
            btnReset = new Button();
            picStudent = new PictureBox();
            openFileDialog1 = new OpenFileDialog();
            openFileDialog2 = new OpenFileDialog();
            btnUpload = new Button();
            btnSave = new Button();
            btnLoad = new Button();
            grpGender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picStudent).BeginInit();
            SuspendLayout();
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(30, 70);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(53, 20);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email :";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(30, 110);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(77, 20);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Password :";
            lblPassword.Click += label3_Click;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(30, 30);
            lblName.Name = "lblName";
            lblName.Size = new Size(56, 20);
            lblName.TabIndex = 3;
            lblName.Text = "Name :";
            // 
            // lblColor
            // 
            lblColor.AutoSize = true;
            lblColor.Location = new Point(30, 190);
            lblColor.Name = "lblColor";
            lblColor.Size = new Size(108, 20);
            lblColor.TabIndex = 4;
            lblColor.Text = "Favorite Color :";
            // 
            // lblBithdate
            // 
            lblBithdate.AutoSize = true;
            lblBithdate.Location = new Point(30, 230);
            lblBithdate.Name = "lblBithdate";
            lblBithdate.Size = new Size(77, 20);
            lblBithdate.TabIndex = 6;
            lblBithdate.Text = "Birthdate :";
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(30, 150);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(64, 20);
            lblGender.TabIndex = 7;
            lblGender.Text = "Gender :";
            lblGender.Click += label8_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.BorderStyle = BorderStyle.FixedSingle;
            lblResult.Location = new Point(30, 400);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(254, 22);
            lblResult.TabIndex = 10;
            lblResult.Text = "(empty, Will be used to show results)";
            lblResult.Click += lblResult_Click;
            // 
            // lblCountry
            // 
            lblCountry.AutoSize = true;
            lblCountry.Location = new Point(30, 270);
            lblCountry.Name = "lblCountry";
            lblCountry.Size = new Size(111, 20);
            lblCountry.TabIndex = 11;
            lblCountry.Text = "Select Country :";
            // 
            // txtName
            // 
            txtName.Location = new Point(150, 30);
            txtName.Name = "txtName";
            txtName.Size = new Size(200, 27);
            txtName.TabIndex = 21;
            txtName.Text = "rqetr";
            txtName.TextChanged += textBox1_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(150, 70);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(200, 27);
            txtEmail.TabIndex = 22;
            txtEmail.Text = "lblEmail";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(150, 110);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(200, 27);
            txtPassword.TabIndex = 25;
            txtPassword.Text = "lblPassword";
            // 
            // grpGender
            // 
            grpGender.Controls.Add(rdoOther);
            grpGender.Controls.Add(rdoFemale);
            grpGender.Controls.Add(rdoMale);
            grpGender.Location = new Point(150, 140);
            grpGender.Name = "grpGender";
            grpGender.Size = new Size(200, 50);
            grpGender.TabIndex = 26;
            grpGender.TabStop = false;
            grpGender.Text = "Gender";
            // 
            // rdoOther
            // 
            rdoOther.AutoSize = true;
            rdoOther.Location = new Point(140, 20);
            rdoOther.Name = "rdoOther";
            rdoOther.Size = new Size(67, 24);
            rdoOther.TabIndex = 2;
            rdoOther.TabStop = true;
            rdoOther.Text = "Other";
            rdoOther.UseVisualStyleBackColor = true;
            // 
            // rdoFemale
            // 
            rdoFemale.AutoSize = true;
            rdoFemale.Location = new Point(70, 20);
            rdoFemale.Name = "rdoFemale";
            rdoFemale.Size = new Size(78, 24);
            rdoFemale.TabIndex = 1;
            rdoFemale.TabStop = true;
            rdoFemale.Text = "Female";
            rdoFemale.UseVisualStyleBackColor = true;
            // 
            // rdoMale
            // 
            rdoMale.AutoSize = true;
            rdoMale.Location = new Point(10, 20);
            rdoMale.Name = "rdoMale";
            rdoMale.Size = new Size(63, 24);
            rdoMale.TabIndex = 0;
            rdoMale.TabStop = true;
            rdoMale.Text = "Male";
            rdoMale.UseVisualStyleBackColor = true;
            // 
            // btnPickColor
            // 
            btnPickColor.Location = new Point(150, 190);
            btnPickColor.Name = "btnPickColor";
            btnPickColor.Size = new Size(94, 29);
            btnPickColor.TabIndex = 27;
            btnPickColor.Text = "Choose Color";
            btnPickColor.UseVisualStyleBackColor = true;
            btnPickColor.Click += btnPickColor_Click;
            // 
            // lblSelectedColor
            // 
            lblSelectedColor.AutoSize = true;
            lblSelectedColor.Location = new Point(300, 190);
            lblSelectedColor.Name = "lblSelectedColor";
            lblSelectedColor.Size = new Size(130, 20);
            lblSelectedColor.TabIndex = 28;
            lblSelectedColor.Text = "No Color Selected";
            // 
            // dtpBirthdate
            // 
            dtpBirthdate.Format = DateTimePickerFormat.Short;
            dtpBirthdate.Location = new Point(150, 230);
            dtpBirthdate.Name = "dtpBirthdate";
            dtpBirthdate.Size = new Size(250, 27);
            dtpBirthdate.TabIndex = 29;
            // 
            // cmbCountry
            // 
            cmbCountry.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCountry.FormattingEnabled = true;
            cmbCountry.Items.AddRange(new object[] { "Yemen", "Egypt", "Oman", "Qatar", "Palestine", "Syria" });
            cmbCountry.Location = new Point(150, 270);
            cmbCountry.Name = "cmbCountry";
            cmbCountry.Size = new Size(151, 28);
            cmbCountry.TabIndex = 30;
            cmbCountry.SelectedIndexChanged += cmbCountry_SelectedIndexChanged;
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(150, 320);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(100, 30);
            btnSubmit.TabIndex = 31;
            btnSubmit.Text = "Register\r\n";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(260, 320);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(100, 30);
            btnReset.TabIndex = 32;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // picStudent
            // 
            picStudent.BorderStyle = BorderStyle.FixedSingle;
            picStudent.Location = new Point(400, 30);
            picStudent.Name = "picStudent";
            picStudent.Size = new Size(120, 120);
            picStudent.SizeMode = PictureBoxSizeMode.StretchImage;
            picStudent.TabIndex = 33;
            picStudent.TabStop = false;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            openFileDialog2.FileName = "openFileDialog2";
            // 
            // btnUpload
            // 
            btnUpload.Location = new Point(400, 160);
            btnUpload.Name = "btnUpload";
            btnUpload.Size = new Size(120, 30);
            btnUpload.TabIndex = 34;
            btnUpload.Text = "Upload Picture";
            btnUpload.UseVisualStyleBackColor = true;
            btnUpload.Click += btnUpload_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(260, 360);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(100, 30);
            btnSave.TabIndex = 35;
            btnSave.Text = "Save Data";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(380, 360);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(100, 30);
            btnLoad.TabIndex = 36;
            btnLoad.Text = "Load Data";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // frmRegistration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(712, 548);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(btnUpload);
            Controls.Add(picStudent);
            Controls.Add(btnReset);
            Controls.Add(btnSubmit);
            Controls.Add(cmbCountry);
            Controls.Add(dtpBirthdate);
            Controls.Add(lblSelectedColor);
            Controls.Add(btnPickColor);
            Controls.Add(grpGender);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(txtName);
            Controls.Add(lblCountry);
            Controls.Add(lblResult);
            Controls.Add(lblGender);
            Controls.Add(lblBithdate);
            Controls.Add(lblColor);
            Controls.Add(lblName);
            Controls.Add(lblPassword);
            Controls.Add(lblEmail);
            Location = new Point(300, 300);
            Name = "frmRegistration";
            Text = "Student Registration From";
            Load += frmRegistration_Load;
            grpGender.ResumeLayout(false);
            grpGender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picStudent).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblEmail;
        private Label lblPassword;
        private Label lblName;
        private Label lblColor;
        private Label lblBithdate;
        private Label lblGender;
        private Label lblResult;
        private Label lblCountry;
        private TextBox txtName;
        private TextBox txtEmail;
        private ContextMenuStrip contextMenuStrip1;
        private TextBox txtPassword;
        private GroupBox grpGender;
        private RadioButton rdoOther;
        private RadioButton rdoFemale;
        private RadioButton rdoMale;
        private Button btnPickColor;
        private Label lblSelectedColor;
        private DateTimePicker dtpBirthdate;
        private ComboBox cmbCountry;
        private Button btnSubmit;
        private Button btnReset;
        private PictureBox picStudent;
        private OpenFileDialog openFileDialog1;
        private OpenFileDialog openFileDialog2;
        private Button btnUpload;
        private Button btnSave;
        private Button btnLoad;
    }
}
